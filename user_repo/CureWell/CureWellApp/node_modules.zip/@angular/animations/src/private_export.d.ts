/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export { AnimationGroupPlayer as ɵAnimationGroupPlayer } from './players/animation_group_player';
export declare const ɵPRE_STYLE = "!";
